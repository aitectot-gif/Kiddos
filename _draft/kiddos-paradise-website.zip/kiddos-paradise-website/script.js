const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.main-nav');

menuToggle?.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
});

nav?.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuToggle?.setAttribute('aria-expanded', 'false');
    menuToggle?.setAttribute('aria-label', 'Open navigation');
  });
});

document.querySelector('#year').textContent = new Date().getFullYear();

// Accessible image lightbox for gallery images.
const lightbox = document.querySelector('#lightbox');
const lightboxImage = lightbox?.querySelector('img');
const lightboxClose = lightbox?.querySelector('.lightbox-close');

document.querySelectorAll('.gallery-item').forEach(item => {
  item.addEventListener('click', () => {
    if (!lightbox || !lightboxImage) return;
    lightboxImage.src = item.dataset.full || item.querySelector('img').src;
    lightboxImage.alt = item.querySelector('img').alt;
    lightbox.showModal();
  });
});
lightboxClose?.addEventListener('click', () => lightbox.close());
lightbox?.addEventListener('click', event => {
  if (event.target === lightbox) lightbox.close();
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && lightbox?.open) lightbox.close();
});

// Front-end validation + mailto draft. Connect a real form service before launch.
const enquiryForm = document.querySelector('#enquiry-form');
const formStatus = document.querySelector('#form-status');
enquiryForm?.addEventListener('submit', event => {
  event.preventDefault();
  if (!enquiryForm.reportValidity()) return;

  const data = new FormData(enquiryForm);
  const parentName = String(data.get('parentName') || '').trim();
  const phone = String(data.get('phone') || '').trim();
  const childAge = String(data.get('childAge') || '');
  const program = String(data.get('program') || '');
  const message = String(data.get('message') || '').trim();

  const subject = encodeURIComponent(`Website enquiry — ${program}`);
  const body = encodeURIComponent(
    `Hello Kiddos Paradise,\\n\\nI would like to enquire about a program.\\n\\n` +
    `Parent/Guardian: ${parentName}\\nPhone: ${phone}\\nChild's age: ${childAge}\\n` +
    `Program: ${program}\\nMessage: ${message || 'Not provided'}\\n\\n` +
    `Please contact me with more details.`
  );
  formStatus.textContent = 'Your details are validated. Opening an email draft now; the enquiry is not sent until you send that email.';
  window.location.href = `mailto:kiddosparadise19@gmail.com?subject=${subject}&body=${body}`;
});
