# Kiddos Paradise Pre School — Static Website

## Files
- `index.html` — complete single-page website with Home, About, Programs, Learning Approach, Facilities, Daycare, Tuition, Gallery, Reviews, Admissions, FAQ and Contact sections.
- `styles.css` — responsive design and visual styling.
- `script.js` — mobile navigation, image lightbox, form validation and email-draft behaviour.
- `assets/kiddos-paradise-logo.png` — supplied logo file copied unchanged.

## Preview
Open `index.html` in a modern browser. Internet access is used for Google Fonts and the sample Unsplash photographs.

## Before launch
1. Replace sample stock photographs with authentic school images and obtain written consent for identifiable children.
2. Confirm the official school name, phone number 2, WhatsApp number, address/map URL, program details, age bands, hours and facilities.
3. The brief's latest second phone number is `91879 63957`; older project notes contain a different number. Verify it.
4. The form validates fields and opens an email draft. It does not submit directly to a server. Connect and test an approved form service/Google Sheet/email workflow before launch.
5. Replace the provisional Google Maps search link with the exact school listing.
6. Add verified parent reviews only. No fabricated reviews are included.
7. Confirm the logo's background treatment with the client. The provided logo file is used without editing.

## Hosting
Upload the folder contents to a static web host or the website root on the selected hosting provider. Preserve the `assets` directory structure.
